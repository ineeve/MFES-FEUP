# Kid2Kid VDM++ Model

http://www.kidtokid.com/

This project models the Kid2Kid stores from a Information System perspective.
So, buying something here refers to buying an item from a client for the store while selling refers to selling to a client.

## Authors
* Joao Esteves
* Renato Campos